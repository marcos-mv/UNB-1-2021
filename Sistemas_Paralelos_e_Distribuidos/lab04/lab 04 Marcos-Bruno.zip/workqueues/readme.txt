execute o servidor e o cliente utilizando 

python3 worker.py

python3 newtask.py