execute o servidor e o cliente utilizando 

python3 recieveLog.py

python3 emitLog.py